﻿using ejemploMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ejemploMVC.Controllers
{
    public class ConversionController : Controller
    {
        // GET: Conversion
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Conversion obConver)
        {
            double rc, rf, rmt, rpulg, rlb, rkg;

            //Temperatura
            rc = (obConver.grac * 9 / 5) + 32;
            ViewBag.rc = rc;
            rf = (obConver.graf - 32) * 5 / 9;
            ViewBag.rf = rf;

            //Peso
            rlb = obConver.kg * 2.205;
            ViewBag.rlb = rlb;
            rkg = obConver.lb / 2.205;
            ViewBag.rkg = rkg;

            //Longitud
            rmt = obConver.pulg / 39.37;
            ViewBag.rmt = rmt;
            rpulg = obConver.mt * 39.37;
            ViewBag.rpulg = rpulg;

            return View(obConver);
        }
    }
}