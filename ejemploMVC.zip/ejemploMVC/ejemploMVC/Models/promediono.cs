﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class promediono
    {
        public double n1 { get; set; }
        public double n2 { get; set; }
        public double n3 { get; set; }
    }
}