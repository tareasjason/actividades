﻿using Ejercicio5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ejercicio5.Controllers
{
    public class OperacionController : Controller
    {
        // GET: Operacion
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Opera()
        {
            //aqui
            Datos objModelo = new Datos();
            string oper = Request.Params["btnOpe"];
            objModelo.variableA = double.Parse(Request.Form["txtvalor1"].ToString());
            objModelo.variableB = double.Parse(Request.Form["txtvalor2"].ToString());
      
            if (objModelo.variableA > objModelo.variableB )
            {
                objModelo.resultado = objModelo.variableA + objModelo.variableB;
                objModelo.resultad = objModelo.variableA - objModelo.variableB;

            }
            else if (objModelo.variableA < objModelo.variableB)
            {
                objModelo.resultado = objModelo.variableB / objModelo.variableA;
            }
            return View("Opera", objModelo);
        }
    }
}