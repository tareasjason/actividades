﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ejemploMVC.Controllers
{
    public class PruebaController : Controller
    {
        //
        // GET: /Prueba/
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(ejemploMVC.Models.calculo obcalculo)
        {
            //suma
            int resultado = obcalculo.numero1 + obcalculo.numero2;
            ViewBag.resultado = resultado;
            return View(obcalculo);
        }

        public ActionResult resta(ejemploMVC.Models.calculo obcalculo)
        {
            //suma
            int resultado = obcalculo.numero1 - obcalculo.numero2;
            ViewBag.resultado = resultado;
            return View(obcalculo);
        }
        public ActionResult multiplicacion(ejemploMVC.Models.calculo obcalculo)
        {
            //suma
            int resultado = obcalculo.numero1 * obcalculo.numero2;
            ViewBag.resultado = resultado;
            return View(obcalculo);
        }
        public ActionResult division (ejemploMVC.Models.calculo obcalculo)
        {
            //division
            int resultado = obcalculo.numero1 / obcalculo.numero2;
            ViewBag.resultado = resultado;
            return View(obcalculo);
        }


    }
}