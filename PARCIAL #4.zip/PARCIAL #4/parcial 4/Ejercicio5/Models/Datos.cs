﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ejercicio5.Models
{
    public class Datos
    {
        public double variableA { get; set; }
        public double variableB { get; set; }
        public double resultad { get; set; }
        public double resultado { get; set; }
    }
}