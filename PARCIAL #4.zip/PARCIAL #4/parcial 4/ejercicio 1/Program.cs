﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_1
{
    class Program
    {
        
        static void Main(string[] args)
        {
           
            var suma = Delegado.operacion(35,10,16,14,35,22,18, (a, b, c, d, e, f, g) => { return a+b+c+d+e+f+g; });
           
            Console.WriteLine("la suma de la temperaturas es de: {0} ", suma);
            Console.WriteLine("Temperatura promedio es :{0}º", suma/7);
            Console.WriteLine("Que clima tan delicioso");

            Console.ReadKey();
        }
    }
}
    
