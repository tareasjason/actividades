﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejercicio2.Models
{
    public class Datos
    {
        public double variableA { get; set; }
        public double variableB { get; set; }
        public double variableC { get; set; }
        public string resultado { get; set; }
       
    }
}