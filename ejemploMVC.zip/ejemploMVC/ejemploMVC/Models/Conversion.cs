﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
        public class Conversion
        {
            public double graf { get; set; }
            public double grac { get; set; }

            public double lb { get; set; }
            public double kg { get; set; }
            public double mt { get; set; }
            public double pulg { get; set; }
        }
    }
