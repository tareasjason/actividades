﻿using ejercicio2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ejercicio3.Controllers
{
    public class OperacionController : Controller
    {
       


        // GET: Operacion
        public ActionResult Index()
        {
            return View();
        }
     
        public ActionResult Opera()
        {
            Datos objModelo = new Datos();
            string oper = Request.Params["btnOpe"];
            objModelo.variableA = double.Parse(Request.Form["txtvalor1"].ToString());
            objModelo.variableB = double.Parse(Request.Form["txtvalor2"].ToString());
            objModelo.variableC = double.Parse(Request.Form["txtvalor3"].ToString());
            if (objModelo.variableA <= 18 && objModelo.variableB>180 && objModelo.variableC <= 80)
            {
                objModelo.resultado ="aprobado";
            }
            else
            {
                objModelo.resultado = "reprobado";
            }
            return View("Opera", objModelo);
        }
    }
}