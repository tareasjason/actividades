﻿using IntroduccionMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IntroduccionMVC.Controllers
{
    public class OperacionesController : Controller
    {
        // GET: Operaciones
       
 public ActionResult Index()
        {
            return View();
        }

        public ActionResult suma()
        {
            Datos objModelo = new Datos();
            objModelo.variableA = 3;
            objModelo.variableB = 5;
            objModelo.resultado = objModelo.variableA + objModelo.variableB;
            ViewData["Resultado"] = objModelo.resultado;
            return View();
        }
        public ActionResult Resta()
        {
            Datos objModelo = new Datos();
            objModelo.variableA = double.Parse(Request.Form["valor1"].ToString());
            objModelo.variableB = double.Parse(Request.Form["valor2"].ToString()); 
            objModelo.resultado = objModelo.variableA - objModelo.variableB;
            return View("Resta",objModelo);
        }

    }
}