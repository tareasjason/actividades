﻿using ejemploMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ejemploMVC.Controllers
{
    public class PromedioController : Controller
    {
        // GET: Promedio
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(promediono obPromedio)
        {
            double promedio = (obPromedio.n1 + obPromedio.n2 + obPromedio.n3) / 3;
            ViewBag.promedio = promedio;

            return View(obPromedio);
        }
    }
}