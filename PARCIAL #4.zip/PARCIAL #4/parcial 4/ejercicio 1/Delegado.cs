﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_1
{
    delegate int Operar2(int a, int b, int c, int d, int e, int f, int g);
    class Delegado
    {
        public int Suma(int a, int b, int c, int d, int e, int f, int g)
        {
            return a + b + c + d + e + f + g;
        }

       

        public static int operacion(int a, int b, int c, int d, int e, int f, int g, Operar2 delg2)
        {
            return delg2(a,b,c,d,e,f,g);

        }
    }
    }




